function [m_win ] = window_Gamma(Nw,sig,fs)
m_win=[];
k=1;
for i=-floor(Nw/2):1:floor(Nw/2)-1
    m_win(k)=(exp(-(1/2*sig^2)*(i/(Nw/2))^2));
    k=k+1;
end
end



