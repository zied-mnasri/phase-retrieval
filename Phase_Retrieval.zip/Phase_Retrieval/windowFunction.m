function [m_win ] = windowFunction( fftsize,m_S,a,b)
%fftsize specifies the size of the FFT
%m_L,m_S are the analysis and synthesis windows, respectively
%m_win is the window that will be generated (hanning)
%Hann window --> a=0.5; b=-0.5
%Hamming window --> a=0.54; b= -.46
m_L=fftsize;
m_win=[];
%Rectangular window magnitude
wr= sqrt(m_S)/sqrt(m_L);
%Scale factor for Hann window
scale=(2*wr)/(sqrt(4*a*a+2*b*b));
for i=1:1:m_L
    m_win(i)=scale*(a+b*cos(2*pi*i/m_L));
end
end

