% Signal reconstruction from original STFT magnitude 
% Copyright Raja Abdelmalek & Zied Mnasri, National school of engineering, University Tunis El Manar
% rajaabdelmalek32@gmail.com, zied.mnasri@enit.utm.tn
%__________________________________________________________________________________________________________________________________
function [SERratio,tf,y] = Phase_Reconstruction_IT_V2020_VF_fct(s,fs,eval,I,method,nfft,Ns,phase0)
%function [SERratio,tf,y] = Phase_Reconstruction_IT_V2020(s1,fs,eval,I,alg,method,sig,nfft,Ns,a,b)
%__________________________________________________________________________________________________________________________________
%
% @inputs       
% wavefile: 'signal.wav'
% eval (0 : original MAG and PHA ; 1: original magnitude and reconstructed phase)
% I: iteration number
% phi0: phase of first frame
% alg (0: x(k,:)=[x(k-1,Ns+1:Nw) zeros(1,Ns)] (with overlap); 1: x(k,:)=x(k-1,:) (without overlap -->for experimental checks)
% method (0: RTISI, 1: eq (22), 2: eq (23))
% sig (sigma : 1.25 for eq (22) ; 2.5 for eq (23)
% nfft: number of points of FFT 
% Ns: Shift 
% a=(hamming 0.54 , hann 0.5)
% b=(hamming -0.46, hann -0.5)
%
%@output       
% SERratio  - Signal error ratio 
% tf        - Processing duration
%________________________________________________________________________________________________________________________________
%clear all
%close all
%wavefile=uigetfile('*.wav'); %Select the wave file to reconstruct
%eval=input('Which evaluation type? 0: with original phase, 1: with reconstructed phase ');
%method=input('Which method ? 0: RTISI, 1: Eq (23), 2: Eq(24), 3: Random phase ');
%phase0=input('Which initial phase ? 0: zero-phase, 1: random phase ');
%nfft=input('Which FFT length?, 256, 512, 1024, etc. ') ;
%shift=input('Which shift rate?, 2, 4, 8, etc. ');
%I=input('Which iteration number?, 1,2,...,20, etc. ') ;
%Write=input('Would you like to write the generated signal in an audio file?, 0: No, 1: Yes ');
%Listen=input('Would you like to listen to the reconstructed signal?, 0: No, 1: Yes '); 

%Ns=floor(nfft/shift);
a=0.54; %0.54 for Hamming; 0.5 for Hann
b=-0.46;% -0.46 for Hamming, -0.5 for Hann 

%________________________________________________________________________________________________________________________________

%[s,fs]=audioread(wavefile);%Read signal
%fs=16000;
%s=downsample(s1,floor(fs1/fs));
[l,~]=size(s);
s=s(1:l,1);
Nw=nfft;
stype='G&L';
delta=0.1;
sig1=1.25;
sig2=2.5;
if method==1
    w=window_Gamma(Nw,sig1,fs); %Gaussian window
elseif method==2
    w=window_Gamma(Nw,sig2,fs); %Gaussian window
else
   w = windowFunction(Nw,Ns,a,-b); %Hamming/Hann window
end
[S,refs,L,M,G,D] = STFT_function( s,Nw,Ns,w,nfft); 
[N1,N2]=size(S);
MAG=abs(S);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
x=zeros(N1,N2);
if phase0==0
    PHA=zeros(N1,N2);
else
    PHA=randn(N1,N2);
end
t0=tic;
for n=2:N1-1
    if eval==0    % Recontruction with original phase and pagnitude    
        PHA(n,:) = angle(S(n,:)); 
    elseif eval==1        % Recontruction with original magnitude and synthesized phase
        x(n,:)=[x(n-1,Ns+1:Nw) zeros(1,Ns)]; %Alg 0 (with overlap (required) 
        z=x(n,:).*w;
        Sx=fft(z, nfft, 2);
        PHA(n,:)=angle(Sx);
        for k=2:N2-1  
            if method==0
                 PHA(n,k)=PHA(n,k); %RTISI-like reconstruction
            elseif method==1
                 sig=1.25;
                %PHA(n,k)=PHA(n,k)-((pi*((sig1*fs)^2)/(2*Nw)))*(log((MAG(n+1,k)*MAG(n+1,k-1)+delta)/(MAG(n-1,k)*MAG(n-1,k-1)+delta)))-pi;%Using eq(23)
                PHA(n,k)=PHA(n,k-1)-((pi*((sig1*fs)^2)/(2*Nw)))*(log((MAG(n+1,k)*MAG(n+1,k-1)+delta)/(MAG(n-1,k)*MAG(n-1,k-1)+delta)))-pi;%Using eq(23)
            elseif method==2
                sig=2.5;
                PHA(n,k)=PHA(n,k)+(Nw/(8*pi*(sig2*fs)^2))*log((MAG(n,k+1)*MAG(n-1,k+1)+delta)/(MAG(n,k-1)*MAG(n-1,k-1)+delta))+(2*pi*k/Nw);%Using eq(24)
            elseif method==3
                PHA(n,k)=randn(1);
            end
        end
    end
    for i=1:I
        MSTFS(n,:) = MAG(n,:).*exp(1j*PHA(n,:));             % recombine magnitude and phase to produce modified STFT
        x(n,:) = real(ifft(MSTFS(n,:), nfft, 2));            % perform inverse STFT analysis
        x(n,:) = x(n,1:Nw);                                 % discard FFT padding from frames 
        if eval==0
            z=x(n,:);
        elseif eval==1
            z=x(n,:).*w;
        end
        Sx=fft(z, nfft, 2);    
        PHA(n,:)=angle(Sx);
    end
    [y] = Overlapandadd( stype,refs,x,w,M,L,n);            % Apply Overlap-and-add
end
y = (y(G+1:L-(Nw-D)))';                                     % remove the padding
tf=toc(t0);                                                 % Processing time

%%%%%Calculate SER ratio %%%%%%%%%%
w1=windowFunction( Nw,Ns,a,b);
[Edb,SERratio]= SERRatio(s,y,w1,Nw,Ns);
%Plot original and reconstructed signals
% ts=(0:length(s)-1)*1000/fs;  
% ty=(0:length(y)-1)*1000/fs;
% figure
% subplot(211)
% plot(ts,s)
% title('Original signal')
% subplot(212)
% plot(ty,y,'r')
% title('Reconstructed signal')
% xlabel('time (msec)')
%Write reconstructed signal
% if Write
% audiowrite('recon_signal.wav',y,fs);
% end
% %Listen to reconstructed signal
% if Listen
% soundsc(y,fs)
% end
 

