function [Edb,SER1,SER2] = SERRatio( x,x1,win,fftsize,m_S)
%SERRatio Calculates the SER of two signals
%SER is an error estimation ratio using spectrograms of the two signals
%computed on a frame-by-frame basis
%x - reference signal
%x1- test signal
%fftsize- fft length
 if nargin==2    % if no of input args less than 3
     fftsize=512; %default winlength
     win=hamming(fftsize);
     m_S=fftsize/4;    %shift size (default: 75% overlap)
     
 end 


%compute spectrograms of x and x1
y1=spectrogram(x,win,m_S,fftsize); 
y2=spectrogram(x1,win,m_S,fftsize);
%output the SER Ratio
SER1=10*log( (sum(sum(abs(y1).^2)))/(sum(sum( (abs(y1)-abs(y2)).^2))));
SER2=20*log( norm(abs(y1),'fro')/norm(abs(y1)-abs(y2),'fro'));

%ratio=20*log( (sum(sum(abs(y1).^2)))/(sum(sum( (abs(y1)-abs(y2)).^2))));
%E = norm(abs(y1)-abs(y2),'fro')/norm(abs(y1),'fro');
%E = magnitudeerr(y1,y2);
Edb = -magnitudeerrdb(y1,y2);
end

