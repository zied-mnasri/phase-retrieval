function [y] = Overlapandadd( stype,refs,x,w,M,L,k )
switch(upper(stype))
    case {'ALLEN & RABINER','A&R'}                   % Allen & Rabiner's method

        y = zeros(1, L); for i = 1:M, y(refs(i,:)) = y(refs(i,:)) + x(i,:); end; % overlap-add processed frames
        wsum = zeros(1, L); for i = 1:M, wsum(refs(i,:)) = wsum(refs(i,:)) + w; end; % overlap-add window samples
        y = y./wsum;                                 % divide out summed-up analysis windows

    case {'GRIFFIN & LIM','G&L'}                     % Griffin & Lim's method
        W=repmat(w,size(x,1),1);
        %x = x .* w(ones(k,1),:);                     % apply synthesis window (Griffin & Lim's method)
        x = x .* W;                     % apply synthesis window (Griffin & Lim's method)
        y = zeros(1, L); for i = 1:k, y(refs(i,:)) = y(refs(i,:)) + x(i,:); end; % overlap-add processed frames
        wsum2 = zeros(1, L); for i = 1:M, wsum2(refs(i,:)) = wsum2(refs(i,:)) + w.^2; end; % overlap-add squared window samples
        y = y./wsum2;                                % divide out squared and summed-up analysis windows    
    otherwise, error(sprintf('%s: synthesis type not supported.', stype));
end
end

