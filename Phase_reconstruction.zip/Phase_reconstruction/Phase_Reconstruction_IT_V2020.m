% Signal reconstruction from original STFT magnitude 
% Copyright Raja Abdelmalek & Zied Mnasri, National school of engineering, University Tunis El Manar
% rajaabdelmalek32@gmail.com, zied.mnasri@enit.utm.tn
%__________________________________________________________________________________________________________________________________
function [SERratio,tf] = Phase_Reconstruction_IT_V2020(wavefile,eval,I,alg,method,sig,nfft,Ns,a,b)
%__________________________________________________________________________________________________________________________________
%
% @inputs       
% wavefile: 'signal.wav'
% eval (0 : original MAG and PHA ; 1: original magnitude and reconstructed phase)
% I: iteration number
% phi0: phase of first frame
% alg (0: x(k,:)=[x(k-1,Ns+1:Nw) zeros(1,Ns)] (with overlap); 1: x(k,:)=x(k-1,:) (without overlap -->for experimental checks)
% method (0: RTISI, 1: eq 2(3), 2: eq (23))
% sig (sigma : 1.25 for eq (22) ; 2.5 for eq (23)
% nfft: number of points of FFT 
% Ns: Shift 
% a=(hamming 0.54 , hann 0.5)
% b=(hamming -0.46, hann -0.5)
%
%@output       
% SERratio       - Signal error ratio 
% tf        - traitement duration
%________________________________________________________________________________________________________________________________

t0=tic;
[s1,fs]=audioread(wavefile);%Read signal
[l,k]=size(s1);
s1=s1(1:l,1);
Nw=nfft;
stype='G&L';
delta=0.1;
w = window_Gamma(Nw,sig,fs); %Gaussian window
[ S,refs,L,M,G,D] = STFT_function( s1,Nw,Ns,w,nfft); 
[N1,N2]=size(S);
amp=abs(S);
phase=angle(S);
[N1,N2]=size(S);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
angle0=zeros(N1,N2);
angle1=zeros(N1,N2);
angle2=zeros(N1,N2);
        
Pha0=zeros(N1,N2);
Pha1=zeros(N1,N2);
Pha2=zeros(N1,N2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
MAG(1,:) = abs(S(1,:));                   % compute STFT magnitude spectra (across each row/frame)
PHA(1,:)=zeros(1,N2);                     %Intitialize phase  
MSTFS = MAG.*exp(1j*PHA);                   
x = real(ifft(MSTFS, nfft, 2));           % perform inverse STFT analysis

for k=2:N1-1
    MAG(k,:) = abs(S(k,:));                   %Original magnitude spectrum
    if eval==0
        PHA(k,:) = angle(S(k,:));             % Recontruction with original phase and pagnitude
        MSTFS = MAG.*exp(1j*PHA);             % recombine magnitude and phase to produce modified STFT
        x = real(ifft(MSTFS, nfft, 2));       % perform inverse STFT analysis
        x = x(:, 1:Nw);       
    elseif eval==1  
        if (alg==0)
            x(k,:)=[x(k-1,Ns+1:Nw) zeros(1,Ns)]; %Alg 0 (with overlap (required) 
        elseif (alg==1)
            x(k,:)=x(k-1,:);                     % Alg 1 (without overlap (only for experimental check))
        end    
        z=x(k,:).*w;
        Sx=fft(z, nfft, 2);    
        Pha(k,:)=angle(Sx);
        for m=2:N2-1  
            Pha0(k,m)=Pha(k,m); %RTISI-like reconstruction
            Pha1(k,m)=Pha(k,m-1)-((pi*((sig*fs)^2)/(2*Nw)))*(log((amp(k+1,m)*amp(k+1,m-1)+delta)/(amp(k,m)*amp(k,m-1)+delta)))-pi;%Using eq(23)
            Pha2(k,m)=Pha(k,m)+(Nw/(8*pi*(sig*fs)^2))*log((amp(k+1,m+1)*amp(k,m+1)+delta)/(amp(k+1,m-1)*amp(k,m-1)+delta))+(2*pi*m/Nw);%Using eq(24)
        end
        if method==0
            PHA(k,:)=Pha0(k,:);%RTISI-like 
        elseif method==1
            PHA(k,:)=Pha1(k,:);%Using eq(23)
        elseif method==2
            PHA(k,:)=Pha2(k,:);%Using eq(24)
        end
        for i=1:I
        %Signal reconstruction 
            MSTFS = MAG.*exp(1j*PHA);                       % recombine magnitude and phase to produce modified STFT
            x = real(ifft(MSTFS, nfft, 2));                 % perform inverse STFT analysis
            x = x(:, 1:Nw);                                 % discard FFT padding from frames 
            z=x(k,:).*w;
            Sx=fft(z, nfft, 2);    
            PHA(k,:)=angle(Sx);
        end
     end
    [y] = Overlapandadd( stype,refs,x,w,M,L,k );            % Apply Overlap-and-add
end   
y = (y(G+1:L-(Nw-D)))';                                     % remove the padding
tf=toc(t0);                                                 % Processing time

%%%%%Calculate SER ratio %%%%%%%%%%
w1=windowFunction( Nw,Ns,a,b);
SERratio= SERRatio( s1,y,w1,Nw,Ns)
%Plot original and reconstructed signals
ts=(0:length(s1)-1)*1000/fs;  
ty=(0:length(y)-1)*1000/fs;
figure
subplot(211)
plot(ts,s1)
title('Original signal')
subplot(212)
plot(ty,y,'r')
title('Reconstructed signal')
xlabel('time (msec)')
%Write reconstructed signal
audiowrite('recon_signal.wav',y,fs);
%Listen to reconstructed signal
soundsc(y,fs)
 

